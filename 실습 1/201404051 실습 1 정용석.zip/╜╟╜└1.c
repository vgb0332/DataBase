﻿#include "stdio.h"
#pragma warning(disable: 4996)

int main()
{
	//변수선언
	int score[100][10];
	int report[100][2];

	int sum = 0;
	int average = 0;
	
	int i = 0;
	int j = 0;

	int nStudents;
	int nSubjects;

	FILE *fp;
	FILE *fp2;
	
	//score.txt파일 오픈
	fp = fopen("score.txt", "r");

	if (fp == NULL)
	{
		printf("No FILE FOUND\n");
	}

	//학생수, 과목수 저장
	fscanf(fp, "%d %d", &nStudents, &nSubjects);

	//각 ith 학생의 점수를 j과목에 해당하는 score[i][j]에 저장!
	for (i = 0; i < nStudents; i++)
	{
		for (j = 0; j < nSubjects; j++)
		{
			fscanf(fp, "%d", &score[i][j]);
		}
	}	/*파일닫기*/	fclose(fp);	/*score배열에 저장된 각 학생의 점수를 더한 총합과 평균 값을 계산 후 report배열에 저장*/	for (i = 0; i < nStudents; i++)	{		for (j = 0; j < nSubjects; j++)		{			sum += score[i][j];			average = sum / nSubjects;		}		report[i][0] = sum;		report[i][1] = average;		sum = 0;		average = 0;		}		/*report텍스트 파일을 생성, report배열에 저장된 값을 옮겨넣는다*/	fp2 = fopen("report.txt", "wt");	fprintf(fp2, "%d\n", nStudents);	for (i = 0; i < nStudents; i++)	{		fprintf(fp2, "%d  ", report[i][0]);		fprintf(fp2, "%d  ", report[i][1]);		fprintf(fp2, "\n");	}	/*파일종료*/		fclose(fp2);	return 0;
}